# Flair.js
<small><b>True Object Oriented JavaScript</b></br><i>Copyright &copy; 2017-2019 Vikas Burman. Distributed under MIT.</i></small>

## Assembly: <u>flair</u>
<small><i>
Version 0.60.52
<br/>Sat, 22 Feb 2020 22:35:33 GMT
<br/>flair.js (362k, 95k minified, 26k gzipped)
</i></small>

### Types
<<types_header>>
<<types_list>>

### Resources
<<resources_header>>
<<resources_list>>

### Assets
<small>(none)</small>


### Routes
<small>(none)</small>


### API
<<types_api>>

</br>
---
<small><small>Built with flairBuild (v1) using fasm (v1) format.</small></small>